# Changelog

## 2.0.0 — 2026-10-26

Consolidated release; see [docs/RELEASE_V2.md](docs/RELEASE_V2.md). Earlier packages and source experiment results are preserved.

## 1.1.0 — 2026-10-21

- Append S1–S9 seeds 930111–930140 using the unchanged paired generator.
- Add 540 new input configurations with analytic initial lower bounds and unknown exact optima.
- Declare the first 10 seeds as development and exploration seeds and the 30 new seeds as the shared test set.
- Keep all 380 earlier inputs, archived numeric bounds, licenses and source experiments unchanged.
- No algorithm evaluation, exact optimization, training or upload is part of this release.

## 1.0.0 — 2026-10-20

Initial licensed release with 380 inputs and 300 archived lower-bound and optimum records.
