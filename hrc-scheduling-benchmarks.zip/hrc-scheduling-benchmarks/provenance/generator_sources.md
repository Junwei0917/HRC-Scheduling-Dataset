# Original generator provenance

The executable portable implementation is `hrc_bench/generators.py`. These short excerpts record the original RNG call order. They are historical reference excerpts, not executable modules. No training or solver source is needed to generate the instances.

## small_random_v1
Source: `reviewer2_tenseed_small_20261016/source/exact_validation.py`, lines 122–160. Full-source SHA-256: `7c40c82479b1868c7c68572aecbf633f4f3f51da524ad88ffce5371238f67f32`.

```python
def generate_validation_instance(
    n_jobs: int = 5,
    n_stations: int = 3,
    humans_per_station: int = 1,
    robots_per_station: int = 2,
    seed: int = 0,
    min_operations: int = 2,
    max_operations: int = 4,
) -> ValidationInstance:
    """Reuse the project mode-generation logic with validation-only settings."""
    if min_operations < 1 or max_operations < min_operations:
        raise ValueError("Invalid inclusive operation-count range")
    rng = np.random.default_rng(seed)
    jobs_modes: list[list[int]] = []

    for _ in range(n_jobs):
        n_operations = int(
            rng.integers(min_operations, max_operations + 1)
        )
        modes = [
            int(rng.choice([H, R, HR], p=cfg.MODE_PROBS))
            for _ in range(n_operations)
        ]
        jobs_modes.append(modes)

    processing_times = [
        [int(rng.integers(5, 11)) for _ in modes]  # 5--10 inclusive
        for modes in jobs_modes
    ]

    return ValidationInstance(
        seed=seed,
        n_jobs=n_jobs,
        n_stations=n_stations,
        humans_per_station=humans_per_station,
        robots_per_station=robots_per_station,
        jobs_modes=jobs_modes,
        processing_times=processing_times,
    )
```

## independent_duration_v1: mode and job-length stream
Source: `reviewer2_cpsat_integer5_20261016/source/mappo_hrc_ppo_full_sharing.py`, lines 87–95. Full-source SHA-256: `a1273fba0148eee176ab82f3263712e104874d0e8be6e21da6753b98229b95aa`.

```python
def build_random_instance(K=None, m=None, n=None, N_jobs=None, seed=7):
    K = cfg.N_STATIONS if K is None else K
    N_jobs = cfg.DEFAULT_N_JOBS if N_jobs is None else N_jobs
    n = cfg.STATION_LAYOUT[0] if n is None else n
    m = cfg.STATION_LAYOUT[1] if m is None else m
    rng = np.random.default_rng(seed)
    jobs = [[int(rng.choice((H, R, HR), p=cfg.MODE_PROBS))
             for _ in range(int(rng.integers(*cfg.JOB_STEPS_RANGE)))] for _ in range(N_jobs)]
    return [(m, n) for _ in range(K)], jobs, 1.0, 10.0
```

## independent_duration_v1: independent integer duration stream
Source: `reviewer2_cpsat_integer5_20261016/integer_instances.py`, lines 7–19. Full-source SHA-256: `6c6fa2f5439ba89296eda5bc0af9cefd4b3fb7cade54f225a183e1f6270e1b57`.

```python
def make_integer_env(layouts, jobs, instance_seed, resource_seed, audited=False):
    env = make_env(layouts, jobs, instance_seed, resource_seed, audited=audited)
    rng = np.random.default_rng(np.random.SeedSequence([instance_seed, 20261016, 1]))
    for job in env.jobs:
        for step in job.steps:
            duration = int(rng.integers(5, 11))
            step.p_table = np.full((env.K, 3), np.inf)
            step.p_table[:, step.mode] = duration
    # Rebuild every time-dependent feature; do not leave scales or suffix work
    # from the originally generated floating-point durations in the actor input.
    env.refresh_feature_scales()
    env.reset_time_and_logs(resample_times=False)
    return env
```

## paired_hr_controls_v1
Source: `hr_controls_tenseed_50_200_20261019/run_experiment.py`, lines 160–191. Full-source SHA-256: `cac5889c8982194fbf33d22144d2a937477325a8f4cef4b9c4e890350c4487a3`.

```python
    mod=library();np,*_=mod.runtime();cases=[]
    for n in (50,200):
        m=225 if n==50 else 900
        for seed in SEEDS:
            lengths=np.array([3]*12+[4]*13+[5]*13+[6]*12 if n==50 else [3]*50+[4]*50+[5]*50+[6]*50)
            np.random.default_rng(np.random.SeedSequence([20261019,n,seed,0])).shuffle(lengths)
            flat_times=np.random.default_rng(np.random.SeedSequence([20261019,n,seed,1])).integers(5,11,m).tolist()
            positions=np.random.default_rng(np.random.SeedSequence([20261019,n,seed,2])).permutation(m)
            inputs={}
            for label,c,p,k,order in DEFINITIONS:
                mix=[(2-3*c)/5,(3-2*c)/5,c];targets=[m*x for x in mix]
                quota=[math.floor(x+1e-9) for x in targets]
                for mode in sorted(range(3),key=lambda x:(-round(targets[x]-quota[x],12),x))[:m-sum(quota)]:quota[mode]+=1
                flat_modes=[None]*m;begin=0
                for mode,count in enumerate(quota):
                    for pos in positions[begin:begin+count]:flat_modes[int(pos)]=mode
                    begin+=count
                modes=[];times=[];begin=0
                for length in lengths:
                    length=int(length);modes.append(flat_modes[begin:begin+length]);times.append(flat_times[begin:begin+length]);begin+=length
                assert begin==m
                if order!="random":
                    for j,ms in enumerate(modes):
                        rank={0:0,2:1,1:2} if order=="aligned" or j%2==0 else {1:0,2:1,0:2}
                        pairs=sorted(zip(ms,times[j]),key=lambda x:rank[x[0]])
                        modes[j],times[j]=[list(x) for x in zip(*pairs)]
                data=dict(seed=seed,jobs=n,stations=3,layouts_humans_robots=[[h*k,r*k] for h,r in LAYOUTS[p]],modes=modes,durations=times)
                input_checks(data);inputs[label]=data;ident=f"n{n}_{label}_seed{seed}"
                d=ROOT/"cases"/ident;d.mkdir();save(d/"instance.json",data)
                case=dict(id=ident,scenario=label,jobs=n,instance_seed=seed,mix=mix,order=order,
                          layout=data["layouts_humans_robots"],capacity_multiplier=k,seconds=BUDGET[n],workers=8,
                          evaluation_seeds=EVAL_SEEDS,model_key=f"{n}_2H3R",instance_sha256=sha(d/"instance.json"),structural_metrics=metrics(data))
```
