# Paired scenarios S1–S9

`S` stands for *Scenario* and is an author-defined label. The same ten base seeds (930101–930110) generate nine paired settings at each of n = 50 and n = 200. Target type fractions become fixed total quotas through the largest-remainder rule rather than independent per-operation Bernoulli draws. Each workstation pair below is written as (humans, robots).

| Code | Name | Archived setting key | Target H/R/HR | Workstation capacities | HR pair capacity P |
|---|---|---|---|---|---:|
| S1 | Baseline | `anchor` | 0.10/0.40/0.50 | (3,2); (2,3); (1,4) | 5 |
| S2 | Double capacity | `capacity_x2` | 0.10/0.40/0.50 | (6,4); (4,6); (2,8) | 10 |
| S3 | Triple capacity | `capacity_x3` | 0.10/0.40/0.50 | (9,6); (6,9); (3,12) | 15 |
| S4 | Lower HR demand | `demand_hr30` | 0.22/0.48/0.30 | (3,2); (2,3); (1,4) | 5 |
| S5 | Higher HR demand | `demand_hr60` | 0.04/0.36/0.60 | (3,2); (2,3); (1,4) | 5 |
| S6 | Uniform layout | `layout_P6` | 0.10/0.40/0.50 | (2,3); (2,3); (2,3) | 6 |
| S7 | Concentrated layout | `layout_P4` | 0.10/0.40/0.50 | (3,1); (2,3); (1,5) | 4 |
| S8 | Aligned operation order | `order_aligned` | 0.10/0.40/0.50 | (3,2); (2,3); (1,4) | 5 |
| S9 | Opposed operation order | `order_opposed` | 0.10/0.40/0.50 | (3,2); (2,3); (1,4) | 5 |

`P = sum_j min(H_j, R_j)`. S1, S6 and S7 share the same totals of 6 humans and 9 robots but have paired capacities of 5, 6 and 4. S2 and S3 multiply each local capacity, not the processing times.

S8 orders every job as H→HR→R; S9 does this for even zero-based job IDs and orders odd IDs as R→HR→H. The (type, duration) pair stays attached when operations are reordered. These transformations preserve per-job work and type counts but change the predecessor order.

S1, S2, S3, S6 and S7 share identical operation types and times; S4 and S5 keep the base durations but change the type quotas; S8 and S9 keep the per-job multiset of (type, duration) pairs. The design is paired and sensitivity-oriented, so the 90 configurations per size are not 90 independent draws.
