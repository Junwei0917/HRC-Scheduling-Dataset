# Organization references

1. [PSPLIB](https://www.om-db.wi.tum.de/psplib/library.php): separates instance sets, problem and generation descriptions, and optimal and heuristic solutions; its instances are generated with ProGen.
2. [JSPLIB](https://github.com/tamy0612/JSPLIB): uses an instance metadata index with name, size and path, and separates a proved optimum from lower and upper bounds when the optimum is unknown.
3. [OR-Library job-shop page](https://people.brunel.ac.uk/~mastjjb/jeb/orlib/jobshopinfo.html): provides the instance data separately from the generation code.
4. [ScheduleOpt job-shop benchmark format](https://github.com/ScheduleOpt/benchmarks/blob/main/jobshop/README.md): illustrates explicit JSON operation, job, step and duration records with precedence lists.

These primary data-library references were consulted on 2026-10-20. Only organizational ideas were used; their instances, source code and job-shop machine constraints were neither copied nor substituted for the HRC resource model.
