# Changes in version 2.0.0

- Every previously published input keeps its raw bytes, IDs, operations, durations and capacities.
- 180 new S1–S9 test inputs (seeds 930141–930150) and 40 new SourceInteger test inputs (seeds 930131–930150) are appended.
- Lower bounds now cover all 1,140 configurations; earlier certified optima are kept and the verified historical CP coverage is added.
- 340 archived complete CP runs, their warm starts, all primal schedules and 203 optimum witnesses are added.
- A standalone CP entry point uses the unchanged heterogeneous-model function bodies, and the earlier uniform model source is kept.
- 1,800 integer training, 8 validation and 1 warmup inputs are kept separate from the test benchmarks.
- Earlier held-out and unexecuted labels are replaced by a registry of actual experiment use. The release reports no new blind-test, convergence or superiority results.
- The existing CC BY 4.0 and MIT licenses and the author metadata are kept. Model weights and policy comparison scores are not included.
- All inputs and certificates were regenerated and validated locally; no long solve, training run, controller restart or remote upload is part of the release.
