# Public-library conventions used

Checked on 2026-10-26 against the primary project pages. Only organizational conventions are adopted; no external data or code is copied.

|Reference|Relevant convention|This release|
|---|---|---|
|[JSPLIB](https://github.com/tamy0612/JSPLIB)|instances directory plus instances.json with size/path/optimum or bounds|Full JSON and text inputs; indexed paths, hashes, lower bounds and nullable optimum|
|[PSPLIB](https://www.om-db.wi.tum.de/psplib/getdata.php?mode=sm)|Separate input archives, lower bounds, and optimal and heuristic solution categories|Bound and optimum table; separate CP run, status and schedule archive|
|[FJSPLIB parser](https://github.com/PyJobShop/FJSPLIB)|Documented job and operation format plus reader/writer package and tests|Documented HRC text and JSON, portable parser and generator, semantic tests|

Ordinary FJSP and JSSP formats cannot encode a same-station human-and-robot demand on multi-capacity stations, so the `.hrc` extension keeps those fields explicit instead of reshaping the scheduling problem to fit another format.

Size context: the JSPLIB README lists 162 instances across seven families, and the PSPLIB single-mode download categories total 2,040 (480 each for j30, j60 and j90, and 600 for j120). This release has 1,140 configurations, 900 of them paired S1–S9 settings, so it does not represent 1,140 independent draws; the auxiliary training and validation inputs and the alternative file representations do not add to that figure. These counts compare library size and say nothing about relative computational difficulty across different models.

The three libraries also distinguish unknown optima from known values, and an instance library does not have to resolve every optimum before publication. The unknown optima here remain null, with valid lower bounds and the available solver records.
