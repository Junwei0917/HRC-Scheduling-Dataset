# Scope

The main benchmark collections contain the frozen integer reviewer suites, all published S1–S9 seeds 930101–930150 and the SourceInteger test inputs. The 40 small-generator extensions at 50 and 200 jobs are prepared but not evaluated. They were retained regardless of algorithm ranking or solver difficulty.

The 1,800 integer training inputs, 8 validation inputs and 1 warmup input are auxiliary data, excluded from the benchmark count. The continuous-time training trajectories, the cancelled continuous-time CP comparison, the 950101 smoke pilots, diagnostic reruns, toy semantic tests, model weights, optimizer states, paper plots, raw controller logs and policy comparison tables are excluded from the release. Input copies that recur across policies or decoders are counted once. The package is an instance and solver reference, not a redistribution of every experiment artifact.
