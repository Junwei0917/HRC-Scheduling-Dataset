# CP-SAT archive and portable model

The archive holds 340 complete-problem runs: 120 small integer inputs, 90 S1–S9 inputs at 50 jobs, 90 at 200 jobs, 20 historical large integer inputs and 20 robot-bottleneck inputs. Copies reused across settings are deduplicated by instance ID, and the raw result bytes and hashes remain intact. The optional HR-to-R diagnostic solve is neither resumed nor required.

Each operation has one common start and end variable and one optional interval per workstation, exactly one of which is present. Duration and type are fixed. Precedence links the operations of each job chain. An HR optional interval is added unchanged to both the human and the robot cumulative constraints of its workstation. Global human, robot and HR-pair cumulatives are valid strengthenings, not replacements for local synchronization.

`hrc_bench/archived_hr_model.py` contains the unchanged `lower_bounds` and `solve_cp` function bodies extracted from the original heterogeneous full-HRC experiment, and `provenance/cp_model_sources.json` records the original file and function hashes. The earlier uniform-capacity implementation is kept under `cpsat/archived_sources/` for historical inspection; its config and exact-validation dependencies belonged to the older research runner. Use `scripts/solve_cp_sat.py` for standalone runs. On uniform inputs both models describe the same problem, but the redundant cuts and solver settings need not reproduce the trajectory of the older runner.

Pass the matching `cpsat/warm_starts/<instance_id>.json` to replay the archived MWKR hint. Without `--warm-start` the CLI uses a serial constructive reference and labels it as such, so its output is not the historical initialization. No policy hint or policy upper bound reaches the CP solver, and instances, times and constraints are unchanged.

Historical full-HRC budgets were 600 s at 50 jobs and 1,800 s at 200 jobs with 8 search workers; the small suite used 600 s and 8 workers, and the solver seed equals the instance seed. The tiny tests use 2 s and 1 worker to check semantics only and are not benchmark results. OR-Tools 9.15.6755 is the version tested for this release. Hardware load, multithreading and solver versions affect the search trajectory and the wall time, so the saved historical runtimes are not reproducible bit for bit.

For the 200-job transfer extension, 58 completed CP records were reused and 32 were newly solved. Three previously suspended and incomplete solves were restarted with their full original 1,800 s budget, and the provenance stays in the source archive. Completed CP results were not re-solved in order to select a preferred outcome. The original 50-job runs span the documented two-case and three-case parallel revision.

Raw result statuses and CP upper bounds are distinct from the post-hoc witnesses that may close a bound; see [BOUNDS.md](BOUNDS.md). Every schedule stores a single HR interval that is checked against both resource capacities. The archival validator does not recompute formal dual-bound proofs.

OR-Tools references: https://developers.google.com/optimization/scheduling/job_shop and https://developers.google.com/optimization/cp/cp_solver . The HRC model extends ordinary machine exclusivity to two simultaneous renewable resources.
