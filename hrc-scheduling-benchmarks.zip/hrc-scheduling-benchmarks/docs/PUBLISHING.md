# Upload to GitHub

1. Unzip the release and use the contents of `hrc-scheduling-benchmarks/` as the repository root. `README.md`, `instances.json`, `configs/` and `instances/` belong at the root, not inside a second upload directory.
2. Create your GitHub repository, then upload with Git (recommended, because the release contains many small instance files):

```bash
git init
git add .
git commit -m "Release HRC scheduling benchmark v2.0.0"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with the URL of the repository you create. Keep `LICENSE-DATA`, `LICENSE-CODE`, `LICENSE`, `license_scope.json` and `CITATION.cff`; do not replace them with a generated license.

3. Run the validation commands listed in `README.md`. The included workflow validates the uploaded files and the tiny CP semantic tests; it does not launch the long experimental queues.
4. After uploading, you can add the repository URL and DOI to `release_metadata.json` and `CITATION.cff`, then regenerate `SHA256SUMS` with `scripts/refresh_checksums.py`. No DOI is registered for this version yet.
