# Format specification, version 1.0

## Canonical JSON

`instance_id` is stable and unique within the release. `collection` distinguishes generator versions. `n_jobs`, `n_workstations`, and `n_operations` are counts. IDs are zero-based. `workstations` lists `workstation_id`, `human_capacity`, `robot_capacity` as named fields, avoiding the historical environment's reversed `(robots,humans)` tuple convention.

`operations` is a flat list. An operation has a globally unique `operation_id`, `job_id`, `sequence_index` within that job, fixed `type` (`H`, `R`, `HR`), integer `processing_time`, `eligible_workstations`, `resource_demand`, and explicit `predecessors`. `jobs` lists each chain's operation IDs in order. `precedences` repeats these edges explicitly as `before`, `after`, `minimum_lag=0` for readers using a graph representation.

| Type | Human demand | Robot demand | Semantics |
|---|---:|---:|---|
| H | 1 | 0 | One human at the selected station |
| R | 0 | 1 | One robot at the selected station |
| HR | 1 | 1 | Both at the **same station**, with identical start and end |

Processing is nonpreemptive. A successor starts no earlier than its predecessor ends. Resource capacities are local and fixed; summing all stations into one global pool is a relaxation, not an equivalent model. Capacity is released before new starts at the same timestamp (`[start,end)`). All jobs have release time 0. Setup, transport, and switching delays are 0. The objective is makespan minimization. Time is measured in abstract integer units, so no physical second or minute is implied.

Every operation is eligible at every listed station and has the same duration there. The operation type is fixed: a scheduler selects a ready type/job and station, not an alternative H-versus-R execution mode for that operation. There are no cross-job precedence edges, fork/joins, or additional alternative-mode durations in this release.

`generation` records the algorithm ID, input seed, setting, base ID, and intended role. `provenance.original_instance_sha256` points to the exact original byte file indexed by `instances.json`. `original_inputs` retains the six-field historical format (`seed,jobs,stations,layouts_humans_robots,modes,durations`). Historical mode codes are H=0, R=1, HR=2; capacities are always `(humans,robots)` there.

Public JSON and HRC text use UTF-8 and LF line endings. Archived originals retain their exact bytes. `.gitattributes` disables Git newline conversion to keep all SHA-256 fingerprints valid on Windows as well as other platforms.

## Compact HRC text

```text
HRC_BENCH 1
INSTANCE stable_instance_id
COLLECTION collection_id
SEED 123
SIZE number_of_jobs number_of_stations
CAPACITIES
0 humans_at_station_0 robots_at_station_0
1 humans_at_station_1 robots_at_station_1
...
JOBS
JOB 0 operation_count_of_job_0
0 H processing_time
1 HR processing_time
...
JOB 1 operation_count_of_job_1
0 R processing_time
...
END
```

Within each job, sequence indices are contiguous from 0. Consecutive operations form precedence edges. All remaining semantics above are mandatory. This is a documented custom format, not the standard job-shop `machine duration` pair format. `hrc_bench.io.parse_text` provides a lossless reader back to historical arrays. The JSON format additionally spells out the same constraints explicitly.
