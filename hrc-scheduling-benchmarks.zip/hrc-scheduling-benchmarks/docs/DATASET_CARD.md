# Dataset card

The figures below describe version 1.1.0 (2026-10-20/21). Current counts, the CP archive and the actual seed use are in [README.md](../README.md), `dataset_statistics.json` and `instance_usage.json`; the earlier held-out labels have been superseded and the inputs are not a blind test set.

- 920 complete input configurations, 170 generation-base groups and 500 distinct type-duration workloads.
- S1–S9 contains 40 input seeds per setting and size: the original 10 were inspected first and 30 were appended for shared test runs.
- All inputs keep 3 stations, fixed H/R/HR demands, chain precedence and positive integer durations from 5 to 10.
- 840 lower-bound records: 169 certified optima and 671 unknown optima. The 540 new lower bounds are analytic only.
- The other 40 historical inputs and 40 reserved inputs have no record in this bound release.
- No new performance evaluation, solver search or training was run, and inputs were not selected on performance.
- Related scenario variants are not independent IID samples, so statistical comparisons must keep the seed and base grouping.
- Data and documentation are CC BY 4.0; software is MIT. No algorithm outcomes or model weights are included.
- A specialist synthetic evaluation collection, not industrial observations and not a general-purpose learning corpus.
