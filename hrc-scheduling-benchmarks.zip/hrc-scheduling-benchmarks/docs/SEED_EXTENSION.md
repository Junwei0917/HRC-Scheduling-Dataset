# S1–S9 seed extension, 2026-10-21

Only input seeds are appended. The frozen `paired_hr_controls_v1` generator, its integer durations from 5 to 10 inclusive, three workstations, 3–6 operations per job, type quotas, capacities, paired layouts and operation reordering are unchanged. The extension widens the S1–S9 sensitivity suite and does not introduce the three processing-time distributions of the older manuscript.

| Role | Seeds | Independent input seeds per scenario and size | Configurations |
|---|---|---:|---:|
| Previously inspected development and exploration | 930101–930110 | 10 | 180 |
| New shared test set | 930111–930140 | 30 | 540 |
| Combined collection | 930101–930140 | 40 | 720 |

There are nine scenarios at each of n = 50 and n = 200. A given input seed has paired scenario variants, so the 540 configurations are not 540 independent IID draws. Together with the other 200 historical and reserved configurations the dataset totals 920 configurations, and every earlier input file and numerical bound is preserved without modification.

The 540 new inputs are shared by the comparisons that use them rather than duplicated per algorithm or per table. Reusing test inputs across competing algorithms is both permissible and useful; the corresponding constraint is that parameters, checkpoints, seeds and budgets should not be chosen on the performance measured on these test cases. The previously inspected seeds can be used for baseline development and calibration, with that exposure disclosed.

Five repeated stochastic runs per input are algorithm-seed repeats, not five new inputs. Average within an input first, then across the 30 inputs of a (scenario, size) group, and test paired algorithm differences; when pooling scenarios, account for the paired seed and base grouping. Thirty inputs is a practical starting point, not a statistical power guarantee.

The ten older inputs are not mixed into the new confirmatory test means, and a pooled 40-seed summary must be labelled combined or exploratory. No case is selected by a desired gap or by which algorithm wins.

Analytic initial lower bounds are supplied for all 540 new cases, and their exact optima are null because no exact solver was run for them. The existing 300 bound records are unchanged, which leaves 840 lower-bound records with 169 certified optima and 671 unknown optima. Publishing a reproducible input does not require that its optimum already be known.

The stronger-baseline comparison is new, and ALNS adapted to HRC is a candidate rather than a tested method. It must preserve local capacities, same-station simultaneous HR use and precedence; a plain RCPSP implementation is not automatically an equivalent solver for this workstation-choice problem.

Sources: [optimization-benchmarking guidance](https://arxiv.org/html/1709.08242), [RCPSP ALNS example](https://alns.readthedocs.io/en/stable/examples/resource_constrained_project_scheduling_problem.html), [JSPLIB unknown-optimum convention](https://github.com/tamy0612/JSPLIB) and [PSPLIB solved/unsolved instances](https://www.om-db.wi.tum.de/psplib/getdata.php?mode=sm).
