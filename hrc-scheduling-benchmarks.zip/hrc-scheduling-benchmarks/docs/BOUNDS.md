# Bound and optimum semantics

The primary table contains only `instance_id`, `lb` and `optimum`. All 1,140 instances have an integer lower bound, and 203 have an established optimum. Null means unknown. A new unsolved input receives the maximum of: the longest job chain, the ceiling of total human-demand work over total human capacity, the ceiling of total robot-demand work over total robot capacity, and the ceiling of HR work over the sum of the local min(H, R) capacities.

Archived solver lower bounds and earlier verified reference bounds can strengthen this analytic bound, and no old certified optimum is discarded. A known optimum must equal both the published lower bound and the makespan of a complete checked schedule. A feasible witness may come from CP, from MWKR or from an archived policy; this does not turn the release into an algorithm comparison table. Source hashes are recorded in `cpsat/optimum_certificates.json` and `provenance/`.

A raw CP upper bound, a warm-start upper bound and a post-hoc feasible witness are distinct objects. `cpsat/runs.json` keeps the original CP reference upper bound and status, and publishing a better witness never rewrites that raw result. A `FEASIBLE` status alone is not an optimality proof: a case is closed either by `OPTIMAL` or by matching valid lower and feasible upper bounds.

`validate_bounds.py` rechecks the input hashes, every archived CP schedule, every warm start, all optimum witnesses and the CSV and reference joins. It does not rerun the historical search or reconstruct a formal unsatisfiability or dual certificate. The solver-reported dual bounds are kept as archival evidence.
