# Reproduction scope

Version 2.0.0 of this note replaces the 2026-10-20/21 text. Current counts, the CP archive and the actual seed use are in `README.md`, `dataset_statistics.json` and `instance_usage.json`, and the earlier held-out labels no longer apply.

This package reproduces complete synthetic instance inputs from standalone generator code, exact configurations and input seeds. `original_inputs` preserves the historical bytes, while the explicit JSON and the compact text files preserve the same operations, chains, fixed H/R/HR types, integer times and local capacities.

The only published benchmark reference numbers are the valid lower bounds and the certified exact optima in `bounds.json`; unknown optima stay null. Checking the archived bound metadata does not reconstruct a solver proof, and an input seed does not reproduce a trained policy. The supplied checks require neither optimization nor training.

All collections have been generated or inspected, so the release provides no new blind learning split. Keep related variants grouped by `generation_base_id` and the shared `workload_sha256`. The HR design followed pilot 950101 before the formal seeds 930101–930110 were fixed, and the pilot is excluded. Robot-bottleneck seeds 700001 and 700002 were explored earlier. The historical and reserved collections stay separately labelled.

The integer full CP problem keeps same-station simultaneous HR use, local capacities and within-job precedence. Time budgets, worker count and the seed rule are recorded in `solver_protocols.json`; future multithreaded wall-clock-limited runs need not return the same incumbents. The complete original experiments remain archived separately.
