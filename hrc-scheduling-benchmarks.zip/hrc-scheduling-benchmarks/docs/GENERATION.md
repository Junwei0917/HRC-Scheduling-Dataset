# Frozen generators and configurations

Every config specifies every input, including the seed, job count, station capacities, settings and algorithm version. The original source function locations and SHA-256 fingerprints are in `provenance/generator_sources.md`. No policy or solver is involved in generation. NumPy is pinned to 2.4.4 for archival replay.

## small_random_v1

For each job, draw its length uniformly from {2, 3, 4}, then draw its fixed types one operation at a time from the H/R/HR probabilities (0.3, 0.4, 0.3) using `default_rng(seed)`. After drawing all jobs' modes, continue with the same RNG to draw integer durations uniformly from {5, ..., 10}. Changing this order changes the dataset. The two resource configurations use identical modes and times for a given (job count, seed).

The main collection has job counts 5, 10, 15, 20, 25 and 30 with ten seeds 810001–810010. The reserved extension uses the same generator at 50 and 200 jobs; those 40 inputs were prepared but not solver-evaluated in that study and are not part of the reported small-scale ten-instance means.

## independent_duration_v1

Draw job lengths from {3, 4, 5, 6} and types in interleaved per-job order with `default_rng(seed)`. Then use a separate duration RNG, `default_rng(SeedSequence([seed, 20261016, 1]))`, for integer durations 5–10 in job and operation order.

The historical large-random collection uses the probabilities (0.3, 0.4, 0.3) with uniform capacities of 1H–2R or 2H–3R per station. The robot-scarce setting uses 2H–1R and the same probabilities. The robot-heavy setting uses 2H–3R and the probabilities (0.1, 0.6, 0.3). All of them use 50 and 200 jobs with seeds 700001–700005. Some base structures and workloads are shared across these collections, so use the index's base and workload hashes rather than collection names alone when constructing later splits.

## paired_hr_controls_v1

The two scales have 225 and 900 operations respectively. At 50 jobs the lengths 3, 4, 5 and 6 occur 12, 13, 13 and 12 times; at 200 jobs each length occurs 50 times. Shuffle the lengths using stream 0, draw durations with stream 1 and draw the type-placement permutation with stream 2. Each stream is `default_rng(SeedSequence([20261019, n_jobs, input_seed, stream]))`.

The target HR share is `c`, and the H/R/HR fractions are `((2 − 3c)/5, (3 − 2c)/5, c)`. Integer quotas come from the largest-remainder rule, using rounded fractional-part keys and the H-before-R-before-HR tie order of the original code. This is quota placement, not independent per-operation categorical sampling.

| Setting | HR share | Station capacities (H, R) | Operation ordering |
|---|---:|---|---|
| anchor | 0.50 | (3,2), (2,3), (1,4), P5 | random quota placement |
| capacity_x2 | 0.50 | (6,4), (4,6), (2,8) | identical to anchor |
| capacity_x3 | 0.50 | (9,6), (6,9), (3,12) | identical to anchor |
| demand_hr30 | 0.30 | P5 | changed type quotas, same lengths and durations |
| demand_hr60 | 0.60 | P5 | changed type quotas, same lengths and durations |
| layout_P6 | 0.50 | (2,3), (2,3), (2,3) | identical to anchor |
| layout_P4 | 0.50 | (3,1), (2,3), (1,5) | identical to anchor |
| order_aligned | 0.50 | P5 | stable type order H→HR→R in every chain |
| order_opposed | 0.50 | P5 | even job IDs H→HR→R; odd IDs R→HR→H |

`P = sum(min(H_i, R_i))`. The layouts P6, P5 and P4 all total 6 humans and 9 robots but have paired capacities 6, 5 and 4. Reordering preserves each job's complete (type, duration) multiset. All variants keep independent chains, and the ordering intervention adds no cross-job graph edges. Seeds 930101–930110 are used at both scales, and the earlier exploratory seed 950101 is not part of these ten-seed means.

All instances are published in full rather than only as a recipe or a seed list. `scripts/generate.py --all --output regenerated --verify-against .` proves that the portable recipes reproduce every published JSON and text instance byte for byte. The original raw byte files may carry different whitespace; their stored SHA-256 values are preserved and their parsed content must match the generated workload exactly.

## Seed-only extension, version 1.1.0

The original paired seeds 930101–930110 remain unchanged. The appended seeds 930111–930140 use the same frozen generator, streams, quotas, capacities, durations and ordering transforms, and no alternative duration distribution from the earlier manuscript is introduced. The new input files are prepared but not performance-evaluated.
