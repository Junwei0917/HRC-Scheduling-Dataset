"""Tiny model-semantics checks only; no published benchmark is re-solved."""
import unittest,json,subprocess,sys,tempfile
from pathlib import Path
from hrc_bench.io import public_instance
from hrc_bench.archived_hr_model import solve_cp
from hrc_bench.schedule_validation import public_schedule,verify_schedule,original_schedule

def instance(modes,durations,layout):
    raw=dict(seed=42,jobs=len(modes),stations=len(layout),layouts_humans_robots=layout,modes=modes,durations=durations)
    spec=dict(instance_id='toy',collection='tests',algorithm='toy',generation_base_id='toy',
              setting='toy',role='unit_test',source_run='toy',source_case_id='toy',original_instance_sha256='none')
    return raw,public_instance(raw,spec)

def serial(public):
    rows=[];time=0
    for op in public['operations']:
        rows.append(dict(operation_id=op['operation_id'],job_id=op['job_id'],type=op['type'],
                         workstation_id=0,start=time,end=time+op['processing_time']))
        time+=op['processing_time']
    return original_schedule(public,rows)

class CompleteHRModelTests(unittest.TestCase):
    def solve(self,modes,durations,layout,expected):
        raw,data=instance(modes,durations,layout)
        result=solve_cp(raw,serial(data),2,1)
        self.assertEqual(result['status'],'OPTIMAL');self.assertEqual(result['lower'],expected)
        self.assertEqual(verify_schedule(data,public_schedule(data,result['schedule']))['makespan'],expected)
    def test_same_total_resources_different_pairing_capacity(self):
        self.solve([[2]]*4,[[5]]*4,[[3,1],[1,3]],10)
        self.solve([[2]]*4,[[5]]*4,[[2,2],[2,2]],5)
    def test_h_and_r_can_overlap(self):self.solve([[0],[1]],[[10],[10]],[[1,1]],10)
    def test_job_precedence(self):self.solve([[0,2,1]],[[3,5,2]],[[2,2],[2,2]],10)
    def test_reject_overlapping_hr(self):
        _,data=instance([[2],[2]],[[5],[5]],[[1,1]])
        rows=[dict(operation_id=k,workstation_id=0,start=0,end=5) for k in (0,1)]
        with self.assertRaises(ValueError):verify_schedule(data,rows)
    def test_reject_precedence_and_duration_changes(self):
        _,data=instance([[0,1]],[[5,5]],[[2,2]])
        with self.assertRaises(ValueError):verify_schedule(data,[dict(operation_id=k,workstation_id=0,start=0,end=5) for k in (0,1)])
        with self.assertRaises(ValueError):verify_schedule(data,[dict(operation_id=0,workstation_id=0,start=0,end=4)])
    def test_portable_cli_on_tiny_fixture(self):
        _,data=instance([[0,2,1]],[[3,5,2]],[[2,2],[2,2]])
        with tempfile.TemporaryDirectory(prefix='hrc-cli-semantics-') as directory:
            directory=Path(directory);input_path=directory/'toy.json';output_path=directory/'result.json'
            input_path.write_text(json.dumps(data),encoding='utf-8')
            script=Path(__file__).resolve().parents[1]/'scripts/solve_cp_sat.py'
            result=subprocess.run([sys.executable,'-B',str(script),str(input_path),'--seconds','2',
                '--workers','1','--output',str(output_path)],capture_output=True,text=True,check=True)
            saved=json.loads(output_path.read_text())
            self.assertEqual(saved['status'],'OPTIMAL');self.assertEqual(saved['upper'],10)
            self.assertIn('Serial reference',saved['initialization'])
            self.assertEqual(verify_schedule(data,saved['schedule'])['makespan'],10)

if __name__=='__main__':unittest.main()
