# Input seeds and usage history

- S1–S9: seeds 930101–930150, both 50 and 200 jobs, 9 paired configurations per base seed.
- Small CP-SAT suite: 810001–810010, 5/10/15/20/25/30 jobs, 1H2R and 2H3R.
- Historical integer and robot-bottleneck suites: 700001–700005.
- SourceInteger tests: 930131–930150, 50 and 200 jobs, uniform 2H3R.
- Prepared small-generator extensions: 810001–810010 at 50 and 200 jobs, labelled separately.
- Auxiliary integer training: training seeds 7, 1007 and 2007; episode `e` uses instance seed `training_seed + e` for `e = 0, ..., 599`. Validation 30007–30014, warmup 30006.

`configs/*.json` holds the exact distributions and RNG streams, and `instance_usage.json` records which inputs each experiment actually used. Seeds 930111–930140 were once held back for future tests and have since been used, so they are not a blind test set. Paired configurations share their workloads by design. The same integer seed under a different generator or job size does not denote the same input, and repeated algorithm or traversal runs are not independent input seeds.
