# Publication status

Version 2.0.0 was assembled on 2026-10-26. Data and documentation are released under CC BY 4.0 and the software under MIT. This version has no public repository, DOI or remote CI run yet: the checks recorded in `RELEASE_VALIDATION.json` were executed locally. All source experiments and earlier packages are preserved in their original form.
