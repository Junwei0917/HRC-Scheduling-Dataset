"""Reproduce archived integer training/validation input bytes; never trains."""
from pathlib import Path
import argparse,hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hrc_bench.generators import generate_raw

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    manifest=json.loads((a.root/'auxiliary/manifest.json').read_text())
    for row in manifest['inputs']:
        rendered=json.dumps(generate_raw(row['generation_spec']),indent=2,allow_nan=False)
        if row['trailing_newline']:rendered+='\n'
        if row['serialization_newline']=='CRLF':rendered=rendered.replace('\n','\r\n')
        elif row['serialization_newline']!='LF':raise ValueError('Unknown archival newline convention')
        encoded=rendered.encode('utf-8')
        assert hashlib.sha256(encoded).hexdigest()==row['sha256']
        assert (a.root/row['path']).read_bytes()==encoded
        target=a.output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(encoded)
    print(json.dumps(dict(passed=True,byte_identical_auxiliary_inputs=len(manifest['inputs']),training_performed=False)))

if __name__=='__main__':main()
