"""Regenerate public JSON and HRC text; never evaluates a scheduling policy."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hrc_bench.generators import generate_raw
from hrc_bench.io import json_bytes,public_instance,text_instance,load_instance

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path);p.add_argument('--all',action='store_true')
    p.add_argument('--output',type=Path,required=True);p.add_argument('--verify-against',type=Path)
    args=p.parse_args();root=Path(__file__).resolve().parents[1]
    configs=sorted((root/'configs').glob('*.json')) if args.all else [args.config]
    if not configs or any(x is None for x in configs):p.error('Specify --config or --all')
    count=0
    for path in configs:
        config=load_instance(path)
        for spec in config['instances']:
            raw=generate_raw(spec);data=public_instance(raw,spec)
            rel=Path('instances')/spec['collection']/(spec['instance_id']+'.json')
            text_rel=Path('text')/spec['collection']/(spec['instance_id']+'.hrc')
            encoded=json_bytes(data);text=text_instance(raw,spec).encode('utf-8')
            if args.verify_against:
                assert (args.verify_against/rel).read_bytes()==encoded,rel
                assert (args.verify_against/text_rel).read_bytes()==text,text_rel
            for name,content in [(rel,encoded),(text_rel,text)]:
                target=args.output/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
            count+=1
    print(f'Regenerated {count} instances; byte comparisons passed' if args.verify_against else f'Generated {count} instances')

if __name__=='__main__':main()
