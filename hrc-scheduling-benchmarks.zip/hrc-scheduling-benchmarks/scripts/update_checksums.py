"""Refresh package integrity hashes after deliberate maintainer edits."""
import argparse
import hashlib
from pathlib import Path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    root = parser.parse_args().root.resolve()
    ignored = {'.git', '__pycache__', 'regenerated', '.venv', '.pytest_cache'}
    paths = sorted(p for p in root.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'
                   and not ignored.intersection(p.relative_to(root).parts))
    lines = [hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(root).as_posix() for p in paths]
    (root/'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode('utf-8'))
    print(f'Hashed {len(paths)} public files; this does not independently validate their contents.')

if __name__ == '__main__':
    main()
