"""Verify reference bounds and archived CP/optimum witnesses, without solving."""
import argparse,json,hashlib,math,csv
from pathlib import Path
from collections import Counter
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hrc_bench.schedule_validation import verify_schedule

def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def analytic_bound(instance):
    work=Counter()
    for o in instance['operations']:work[o['type']]+=o['processing_time']
    stations=instance['workstations'];operations={o['operation_id']:o for o in instance['operations']}
    ceil=lambda a,b:(a+b-1)//b
    return max(ceil(work['H']+work['HR'],sum(s['human_capacity'] for s in stations)),
               ceil(work['R']+work['HR'],sum(s['robot_capacity'] for s in stations)),
               ceil(work['HR'],sum(min(s['human_capacity'],s['robot_capacity']) for s in stations)),
               max(sum(operations[o]['processing_time'] for o in j['operation_ids']) for j in instance['jobs']))

def validate(root):
    index={r['instance_id']:r for r in load(root/'instances.json')}
    rows=load(root/'bounds.json');bounds={r['instance_id']:r for r in rows}
    assert len(rows)==len(bounds)==len(index) and set(bounds)==set(index)
    metadata=load(root/'bounds_metadata.json');assert sha(root/'bounds.json')==metadata['records_sha256']
    provenance={r['instance_id']:r for r in load(root/'provenance/bounds_sources.json')}
    certificates={r['instance_id']:r for r in load(root/'cpsat/optimum_certificates.json')}
    cp_runs=load(root/'cpsat/runs.json');cp_by_id={r['instance_id']:r for r in cp_runs}
    previous={r['instance_id']:r for r in load(root/'provenance/previous_bound_release.json')['bounds']}
    known=0;intervals=0;cp_statuses=Counter()
    for key,row in bounds.items():
        assert set(row)=={'instance_id','lb','optimum'}
        lower,optimum=row['lb'],row['optimum'];assert type(lower)is int and lower>0
        instance=load(root/index[key]['path'])
        expected=max(analytic_bound(instance),previous.get(key,{}).get('lb',0),
                     cp_by_id.get(key,{}).get('reported_lower',0))
        assert lower==expected, 'A published LB must trace to an analytic or archived bound'
        assert index[key]['lb']==lower and index[key]['optimum']==optimum
        assert sha(root/index[key]['path'])==index[key]['sha256']==provenance[key]['input_sha256']
        if optimum is not None:
            assert type(optimum)is int and lower==optimum
            cert=certificates[key];assert cert['optimum']==optimum
            assert sha(root/cert['witness_path'])==cert['witness_sha256']
            checked=verify_schedule(instance,load(root/cert['witness_path']))
            assert checked['makespan']==optimum
            known+=1
        else:assert key not in certificates
    assert known==metadata['known_optima'] and len(rows)-known==metadata['unknown_optima']
    for run in cp_runs:
        key=run['instance_id'];instance=load(root/index[key]['path'])
        for p,h in [(run['raw_result_path'],run['raw_result_sha256']),
                    (run['schedule_path'],run['schedule_sha256']),
                    (run['warm_start_path'],run['warm_start_sha256'])]:assert sha(root/p)==h
        primal=verify_schedule(instance,load(root/run['schedule_path']))
        verify_schedule(instance,load(root/run['warm_start_path']))
        assert primal['makespan']==run['reference_upper'] and run['reported_lower']<=run['reference_upper']
        raw=load(root/run['raw_result_path'])
        assert run['published_original_sha256']==index[key]['original_sha256']
        raw_lower=raw.get('lower',raw.get('best_bound'))
        if raw_lower is not None:assert math.ceil(raw_lower-1e-8)<=run['reported_lower']
        if run['status']=='OPTIMAL':assert run['reported_lower']==run['reference_upper']
        assert raw['status']==run['status']
        assert bounds[key]['lb']>=run['reported_lower']
        intervals+=primal['operations'];cp_statuses[run['status']]+=1
    assert len(provenance)==len(index) and len(cp_by_id)==len(cp_runs)
    with (root/'bounds.csv').open(encoding='utf-8',newline='') as stream:
        csv_rows=list(csv.DictReader(stream))
    assert len(csv_rows)==len(rows)
    for row in csv_rows:
        normalized=dict(instance_id=row['instance_id'],lb=int(row['lb']),
                        optimum=int(row['optimum']) if row['optimum'] else None)
        assert normalized==bounds[row['instance_id']]
    with (root/'instances.csv').open(encoding='utf-8',newline='') as stream:
        csv_index=list(csv.DictReader(stream))
    assert len(csv_index)==len(index)
    for row in csv_index:
        reference=index[row['instance_id']]
        assert row['path']==reference['path'] and row['sha256']==reference['sha256']
        assert int(row['lb'])==reference['lb']
        assert (int(row['optimum']) if row['optimum'] else None)==reference['optimum']
    return dict(passed=True,complete=True,instances=len(index),bound_records=len(rows),
                known_optima=known,unknown_optima=len(rows)-known,cp_runs=len(cp_runs),
                cp_statuses=dict(cp_statuses),cp_schedule_intervals=intervals,
                optimum_witnesses_checked=known,all_reference_hashes_checked=True,
                primal_feasibility_rechecked=True,csv_and_json_consistent=True,archived_dual_bounds_not_resolved=True,
                no_benchmark_solver_or_training_invoked=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--report',type=Path)
    a=p.parse_args();result=validate(a.root.resolve());encoded=json.dumps(result,indent=2)+'\n'
    if a.report:a.report.write_text(encoded,encoding='utf-8')
    print(encoded)
