"""Validate every published instance, lossless format, original hash and generator.

Only file and format checks are performed: no scheduling, optimization, policy
evaluation or training.
"""
import argparse
from collections import Counter,defaultdict
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hrc_bench.io import load_instance,raw_from_public,parse_text,public_instance,json_bytes,DEMANDS
from hrc_bench.generators import generate_raw

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check_raw(raw):
    assert type(raw['seed'])is int and type(raw['jobs'])is int and raw['jobs']>0
    assert raw['stations']==len(raw['layouts_humans_robots'])==3
    assert all(len(x)==2 and all(type(c)is int and c>0 for c in x) for x in raw['layouts_humans_robots'])
    assert len(raw['modes'])==len(raw['durations'])==raw['jobs']
    for modes,times in zip(raw['modes'],raw['durations']):
        assert len(modes)==len(times)>0
        assert all(type(x)is int and x in [0,1,2] for x in modes)
        assert all(type(x)is int and 5<=x<=10 for x in times)

def validate(root,regenerate=True,checksums=True):
    index=load_instance(root/'instances.json');specs={}
    for p in sorted((root/'configs').glob('*.json')):
        for spec in load_instance(p)['instances']:
            assert spec['instance_id'] not in specs
            specs[spec['instance_id']]=spec
    assert len(index)==len(specs)
    counts=Counter();ops=arcs=0;paired=defaultdict(dict);workloads=set();bases=set();reserved=0
    for row in index:
        spec=specs[row['instance_id']]
        assert row['collection']==spec['collection']
        for key,hash_key in [('path','sha256'),('text_path','text_sha256'),('original_path','original_sha256')]:
            path=(root/row[key]).resolve();assert path.is_relative_to(root.resolve()) and path.is_file()
            assert digest(path)==row[hash_key],row['instance_id']
        data=load_instance(root/row['path']);raw=load_instance(root/row['original_path']);check_raw(raw)
        assert (row['jobs'],row['workstations'],row['instance_seed'],row['setting'],row['role'])==(raw['jobs'],raw['stations'],raw['seed'],spec['setting'],spec['role'])
        assert row['generation_base_id']==spec['generation_base_id']
        workload_hash=hashlib.sha256(json_bytes(dict(modes=raw['modes'],durations=raw['durations']))).hexdigest()
        assert row['workload_sha256']==workload_hash
        assert row['original_sha256']==spec['original_instance_sha256']
        assert raw_from_public(data)==raw
        parsed=parse_text((root/row['text_path']).read_text(encoding='utf-8'))
        assert parsed==dict(instance_id=spec['instance_id'],collection=spec['collection'],raw=raw)
        assert json_bytes(public_instance(raw,spec))==(root/row['path']).read_bytes()
        if regenerate:assert generate_raw(spec)==raw,('generator_mismatch',row['instance_id'])
        assert data['n_operations']==sum(map(len,raw['modes']))==row['operations']
        assert len(data['operations'])==data['n_operations']
        assert [o['operation_id'] for o in data['operations']]==list(range(data['n_operations']))
        jobs={j['job_id']:j for j in data['jobs']};assert sorted(jobs)==list(range(raw['jobs']))
        expected_arcs=[];by_id={x['operation_id']:x for x in data['operations']}
        for j,job in jobs.items():
            assert job['release_time']==0 and len(job['operation_ids'])==len(raw['modes'][j])
            for step,op_id in enumerate(job['operation_ids']):
                o=by_id[op_id];assert o['job_id']==j and o['sequence_index']==step
                expected_predecessors=[] if step==0 else [job['operation_ids'][step-1]]
                assert o['predecessors']==expected_predecessors
                assert o['resource_demand']==DEMANDS[o['type']]
                assert o['eligible_workstations']==list(range(raw['stations']))
                if step:expected_arcs.append(dict(before=expected_predecessors[0],after=op_id,minimum_lag=0))
        assert data['precedences']==expected_arcs
        assert data['model']['hr_requires_same_station_simultaneous_interval']
        assert data['model']['operation_type_fixed'] and data['model']['nonpreemptive']
        assert [len(x) for x in raw['modes']]==row['operations_per_job']
        assert Counter(x['type'] for x in data['operations'])==Counter(row['type_counts'])
        if spec['algorithm']=='paired_hr_controls_v1':
            assert data['n_operations']==(225 if raw['jobs']==50 else 900)
            assert Counter(map(len,raw['modes']))==({3:12,4:13,5:13,6:12} if raw['jobs']==50 else {3:50,4:50,5:50,6:50})
            paired[(raw['jobs'],raw['seed'])][spec['setting']]=raw
        counts[row['collection']]+=1;ops+=data['n_operations'];arcs+=len(expected_arcs)
        bases.add(spec['generation_base_id']);workloads.add(row['workload_sha256'])
        reserved+=spec['role']=='prepared_not_evaluated'
    for (_,seed),settings in paired.items():
        assert set(settings)=={'anchor','capacity_x2','capacity_x3','demand_hr30','demand_hr60','layout_P6','layout_P4','order_aligned','order_opposed'}
        a=settings['anchor']
        for setting in ['capacity_x2','capacity_x3','layout_P6','layout_P4']:
            assert settings[setting]['modes']==a['modes'] and settings[setting]['durations']==a['durations']
        for setting,multiplier in [('capacity_x2',2),('capacity_x3',3)]:
            assert settings[setting]['layouts_humans_robots']==[[h*multiplier,r*multiplier] for h,r in a['layouts_humans_robots']]
        for setting in ['demand_hr30','demand_hr60']:assert settings[setting]['durations']==a['durations']
        for setting in ['order_aligned','order_opposed']:
            x=settings[setting]
            assert [sorted(zip(m,t)) for m,t in zip(x['modes'],x['durations'])]==[sorted(zip(m,t)) for m,t in zip(a['modes'],a['durations'])]
        assert [sum(min(h,r) for h,r in settings[x]['layouts_humans_robots']) for x in ['layout_P6','anchor','layout_P4']]==[6,5,4]
    checked=0
    if checksums:
        listed=[]
        for line in (root/'SHA256SUMS').read_text(encoding='utf-8').splitlines():
            expected,rel=line.split('  ',1);path=(root/rel).resolve()
            assert path.is_relative_to(root.resolve()) and digest(path)==expected,rel;checked+=1;listed.append(rel)
        assert len(listed)==len(set(listed))
        ignored={'.git','__pycache__','regenerated','regenerated_auxiliary','local_runs','.venv','.pytest_cache'}
        tracked={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS' and not ignored.intersection(p.relative_to(root).parts)}
        assert set(listed)==tracked,'Unlisted or missing package files'
    return dict(passed=True,instances=len(index),operations=ops,precedence_arcs=arcs,collections=dict(counts),
                reserved_not_evaluated=reserved,generation_bases=len(bases),unique_workloads=len(workloads),
                hr_paired_base_groups=len(paired),original_input_hashes_verified=True,
                json_and_text_roundtrip=True,portable_generator_exact_match=regenerate,
                positive_integer_times_5_to10=True,explicit_types_demands_capacities_and_precedence=True,
                resource_pairing_semantics_verified=True,checksum_files_checked=checked,
                no_solver_or_training_invoked=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--report',type=Path);parser.add_argument('--skip-regenerate',action='store_true')
    args=parser.parse_args();result=validate(args.root.resolve(),not args.skip_regenerate)
    if args.report:args.report.write_bytes(json_bytes(result))
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
