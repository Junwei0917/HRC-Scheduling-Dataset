"""Refresh the public-file SHA-256 manifest after an intentional release edit."""
import argparse,hashlib
from pathlib import Path

IGNORED={'.git','__pycache__','.venv','.pytest_cache','regenerated','regenerated_auxiliary','local_runs'}
def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=p.parse_args()
    root=a.root.resolve();rows=[]
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if not path.is_file() or path.name=='SHA256SUMS' or IGNORED.intersection(rel.parts):continue
        rows.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+rel.as_posix())
    (root/'SHA256SUMS').write_text('\n'.join(rows)+'\n',encoding='utf-8')
    print(f'Wrote SHA256SUMS for {len(rows)} public files')

if __name__=='__main__':main()
