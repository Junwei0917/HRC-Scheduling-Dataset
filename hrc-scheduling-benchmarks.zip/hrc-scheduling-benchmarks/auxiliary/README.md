# Separate integer training and validation inputs

The 1,800 training inputs were used in the integer Full/Single paired study. The capacity-v2 pilot reused the 600 inputs that belong to seed 7. The eight validation inputs are seeds 30007–30014, and 30006 is a warmup. All are 50-job, 3-station 2H3R inputs with 3–6 operations per job, type probabilities H/R/HR = .3/.4/.3 and integer durations 5–10, drawn with `independent_duration_v1`.

The files are complete raw arrays: `modes` 0/1/2 mean H/R/HR, `modes[j][k]` and `durations[j][k]` describe operation k of job j, and `layouts_humans_robots` lists each station's capacities. The manifest provides the exact generation recipe, input hash, episode and role. Reproduce them with `scripts/generate_auxiliary.py`. They are auxiliary data only: not main benchmark instances, not unseen test inputs, and not a substitute for the older continuous-time MPPO training data.

The archival newline convention (LF or CRLF) is recorded per file. The generator preserves it exactly, and `.gitattributes` disables Git newline normalization so the original-byte hashes stay valid across platforms.
