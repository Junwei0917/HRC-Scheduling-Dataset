# -*- coding: utf-8 -*-
"""License-free exact scheduling model using OR-Tools CP-SAT."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from ortools.sat.python import cp_model

from config import H, HR, MODE_NAMES, R
from exact_validation import ValidationInstance, operation_name


@dataclass
class CpSatResult:
    status: str
    status_code: int
    makespan: float | None
    best_bound: float | None
    relative_gap: float | None
    runtime: float
    num_variables: int
    num_boolean_variables: int
    num_constraints: int
    conflicts: int
    branches: int
    time_horizon: int
    schedule: list[dict[str, Any]]
    response_stats: str


def resource_lower_bound(instance: ValidationInstance) -> int:
    max_job_chain = max(sum(times) for times in instance.processing_times)
    human_work = 0
    robot_work = 0
    for _job_id, _operation_id, mode, processing_time in instance.operations():
        if mode in (H, HR):
            human_work += processing_time
        if mode in (R, HR):
            robot_work += processing_time
    human_capacity = instance.n_stations * instance.humans_per_station
    robot_capacity = instance.n_stations * instance.robots_per_station
    return max(
        max_job_chain,
        math.ceil(human_work / human_capacity),
        math.ceil(robot_work / robot_capacity),
    )


def solve_with_cp_sat(
    instance: ValidationInstance,
    upper_bound_schedule: list[dict[str, Any]],
    upper_bound: float,
    time_limit: float = 600.0,
    num_workers: int = 8,
) -> CpSatResult:
    """Solve the same flexible-workstation scheduling problem to proven optimality.

    Each operation has one optional interval per workstation. Exactly one is
    present, so presence simultaneously selects the workstation and activates
    its non-preemptive interval. HR intervals enter both cumulative constraints
    of that same workstation.
    """
    horizon = int(math.ceil(upper_bound))
    lower_bound = resource_lower_bound(instance)
    if horizon < lower_bound:
        raise ValueError(
            f"Feasible upper bound {horizon} is below lower bound {lower_bound}"
        )

    model = cp_model.CpModel()
    operations = list(instance.operations())
    starts: dict[tuple[int, int], cp_model.IntVar] = {}
    ends: dict[tuple[int, int], cp_model.IntVar] = {}
    presences: dict[tuple[int, int, int], cp_model.IntVar] = {}
    intervals: dict[tuple[int, int, int], cp_model.IntervalVar] = {}
    human_intervals: dict[int, list[cp_model.IntervalVar]] = {
        workstation_id: [] for workstation_id in range(instance.n_stations)
    }
    robot_intervals: dict[int, list[cp_model.IntervalVar]] = {
        workstation_id: [] for workstation_id in range(instance.n_stations)
    }
    global_human_intervals: list[cp_model.IntervalVar] = []
    global_robot_intervals: list[cp_model.IntervalVar] = []

    for job_id, operation_id, mode, processing_time in operations:
        earliest_start = sum(instance.processing_times[job_id][:operation_id])
        latest_end = horizon - sum(
            instance.processing_times[job_id][operation_id + 1 :]
        )
        latest_start = latest_end - processing_time
        key = (job_id, operation_id)
        starts[key] = model.new_int_var(
            earliest_start,
            latest_start,
            f"start_{job_id}_{operation_id}",
        )
        ends[key] = model.new_int_var(
            earliest_start + processing_time,
            latest_end,
            f"end_{job_id}_{operation_id}",
        )
        # Exactly one optional workstation interval below already implies this
        # equality. Keeping it explicit gives the scheduling propagators a
        # mandatory operation interval before the workstation is selected.
        model.add(ends[key] == starts[key] + processing_time)
        global_interval = model.new_interval_var(
            starts[key],
            processing_time,
            ends[key],
            f"global_interval_{job_id}_{operation_id}",
        )
        if mode in (H, HR):
            global_human_intervals.append(global_interval)
        if mode in (R, HR):
            global_robot_intervals.append(global_interval)
        operation_presences = []
        for workstation_id in range(instance.n_stations):
            presence = model.new_bool_var(
                f"present_{job_id}_{operation_id}_{workstation_id}"
            )
            interval = model.new_optional_interval_var(
                starts[key],
                processing_time,
                ends[key],
                presence,
                f"interval_{job_id}_{operation_id}_{workstation_id}",
            )
            presences[(job_id, operation_id, workstation_id)] = presence
            intervals[(job_id, operation_id, workstation_id)] = interval
            operation_presences.append(presence)
            if mode in (H, HR):
                human_intervals[workstation_id].append(interval)
            if mode in (R, HR):
                robot_intervals[workstation_id].append(interval)
        model.add_exactly_one(operation_presences)

    for job_id, modes in enumerate(instance.jobs_modes):
        for operation_id in range(len(modes) - 1):
            model.add(
                starts[(job_id, operation_id + 1)]
                >= ends[(job_id, operation_id)]
            )

    for workstation_id in range(instance.n_stations):
        if human_intervals[workstation_id]:
            model.add_cumulative(
                human_intervals[workstation_id],
                [1] * len(human_intervals[workstation_id]),
                instance.humans_per_station,
            )
        if robot_intervals[workstation_id]:
            model.add_cumulative(
                robot_intervals[workstation_id],
                [1] * len(robot_intervals[workstation_id]),
                instance.robots_per_station,
            )

    # Redundant global capacities are implied by the station-level capacities,
    # but substantially strengthen propagation before station choices are fixed.
    model.add_cumulative(
        global_human_intervals,
        [1] * len(global_human_intervals),
        instance.n_stations * instance.humans_per_station,
    )
    model.add_cumulative(
        global_robot_intervals,
        [1] * len(global_robot_intervals),
        instance.n_stations * instance.robots_per_station,
    )

    makespan = model.new_int_var(lower_bound, horizon, "makespan")
    last_operation_ends = [
        ends[(job_id, len(modes) - 1)]
        for job_id, modes in enumerate(instance.jobs_modes)
    ]
    model.add_max_equality(makespan, last_operation_ends)
    model.minimize(makespan)

    warm_start = {
        (int(row["job_id"]), int(row["operation_id"])): row
        for row in upper_bound_schedule
    }
    for job_id, operation_id, _mode, _processing_time in operations:
        key = (job_id, operation_id)
        row = warm_start[key]
        selected_workstation = int(row["workstation_id"])
        model.add_hint(starts[key], int(round(float(row["start"]))))
        model.add_hint(ends[key], int(round(float(row["end"]))))
        for workstation_id in range(instance.n_stations):
            model.add_hint(
                presences[(job_id, operation_id, workstation_id)],
                int(workstation_id == selected_workstation),
            )
    model.add_hint(makespan, horizon)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = float(time_limit)
    solver.parameters.num_search_workers = int(num_workers)
    solver.parameters.random_seed = int(instance.seed)
    solver.parameters.relative_gap_limit = 0.0
    solver.parameters.absolute_gap_limit = 0.0
    solver.parameters.log_search_progress = False
    solver.parameters.symmetry_level = 2
    solver.parameters.exploit_all_precedences = True
    solver.parameters.use_overload_checker_in_cumulative = True
    solver.parameters.use_timetable_edge_finding_in_cumulative = True
    solver.parameters.use_hard_precedences_in_cumulative = True
    solver.parameters.use_dynamic_precedence_in_cumulative = True
    status_code = solver.solve(model)
    status = solver.status_name(status_code)
    has_solution = status_code in (cp_model.OPTIMAL, cp_model.FEASIBLE)

    schedule: list[dict[str, Any]] = []
    if has_solution:
        for job_id, operation_id, mode, processing_time in operations:
            selected = [
                workstation_id
                for workstation_id in range(instance.n_stations)
                if solver.value(
                    presences[(job_id, operation_id, workstation_id)]
                )
                == 1
            ]
            if len(selected) != 1:
                raise RuntimeError(
                    f"CP-SAT selected {len(selected)} workstations for "
                    f"{operation_name(job_id, operation_id)}"
                )
            start = int(solver.value(starts[(job_id, operation_id)]))
            end = int(solver.value(ends[(job_id, operation_id)]))
            schedule.append(
                {
                    "operation": operation_name(job_id, operation_id),
                    "job_id": job_id,
                    "operation_id": operation_id,
                    "workstation_id": selected[0],
                    "mode": MODE_NAMES[mode],
                    "start": float(start),
                    "end": float(end),
                    "processing_time": processing_time,
                }
            )
        schedule.sort(
            key=lambda row: (
                row["start"],
                row["workstation_id"],
                row["job_id"],
                row["operation_id"],
            )
        )

    objective = float(solver.objective_value) if has_solution else None
    best_bound = float(solver.best_objective_bound)
    relative_gap = None
    if has_solution and objective:
        relative_gap = max(0.0, (objective - best_bound) / abs(objective))
    proto = model.Proto()
    boolean_variables = sum(
        list(variable.domain) == [0, 1] for variable in proto.variables
    )
    return CpSatResult(
        status=status,
        status_code=int(status_code),
        makespan=objective,
        best_bound=best_bound,
        relative_gap=relative_gap,
        runtime=float(solver.wall_time),
        num_variables=len(proto.variables),
        num_boolean_variables=boolean_variables,
        num_constraints=len(proto.constraints),
        conflicts=int(solver.num_conflicts),
        branches=int(solver.num_branches),
        time_horizon=horizon,
        schedule=schedule,
        response_stats=solver.response_stats(),
    )
